public class InvalidVelocityException extends Exception {
    InvalidVelocityException() {
        super();
    }

    InvalidVelocityException(String message) {
        super(message);
    }
}
