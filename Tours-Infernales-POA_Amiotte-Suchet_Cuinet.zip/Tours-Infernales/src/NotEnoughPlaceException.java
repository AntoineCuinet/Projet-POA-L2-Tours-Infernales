public class NotEnoughPlaceException extends Exception {
    NotEnoughPlaceException() {
        super();
    }

    NotEnoughPlaceException(String message) {
        super(message);
    }
}
