public enum State {
    ALIVE,
    DEATH,
    EXPLODE,
    FREEZE;
}
